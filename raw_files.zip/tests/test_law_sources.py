"""Synthetic API contracts only: these fixtures are not official law evidence."""

from __future__ import annotations

import json
import os
import unittest
from unittest.mock import patch

import httpx

from rulecraft.law_sources import LawClient, LawSourceError, is_deleted_article


OC = "fixture-account-secret"


def law_catalog(total: int = 1, extra: str = "", source_id: str = "00123", version_id: str = "987") -> bytes:
    return f"""<LawSearch><totalCnt>{total}</totalCnt><law>
      <법령ID>{source_id}</법령ID><법령일련번호>{version_id}</법령일련번호>
      <법령명한글>합성 검증용 법률</법령명한글><공포일자>20250901</공포일자>
      <시행일자>2026-01-01</시행일자><공포번호>12345</공포번호>{extra}
      </law></LawSearch>""".encode()


FULL_LAW = """<?xml version="1.0" encoding="UTF-8"?>
<법령><기본정보><법령ID>00123</법령ID><법령일련번호>987</법령일련번호>
<법령명_한글>합성 검증용 법률</법령명_한글><공포일자>20250901</공포일자>
<시행일자>20260101</시행일자><공포번호>12345</공포번호></기본정보>
<조문><조문단위><조문번호>7</조문번호><조문가지번호>2</조문가지번호><조문제목>검증</조문제목>
<조문내용>제7조의2(검증) 검증의 범위는 다음과 같다.</조문내용>
<항><항번호>①</항번호><항내용>① 확인하여야 한다.</항내용>
<호><호번호>1.</호번호><호내용>1. 기록</호내용><목><목번호>가.</목번호><목내용>가. 원본 기록</목내용></목></호></항>
</조문단위><조문단위><조문번호>8</조문번호><조문제목>직접 호</조문제목>
<조문내용>제8조(직접 호) 다음 각 호.</조문내용><호><호번호>2)</호번호><호내용>2) 절차</호내용></호>
</조문단위></조문>
<부칙><부칙단위><부칙공포일자>20250901</부칙공포일자><부칙내용>이 법은 2026년 1월 1일부터 시행한다.</부칙내용></부칙단위></부칙>
<별표><별표단위><별표번호>1</별표번호><별표제목>신청서</별표제목>
<별표PDF파일링크>https://www.law.go.kr/LSW/flDownload.do?flSeq=42</별표PDF파일링크></별표단위></별표>
</법령>""".encode()


FULL_ADMINISTRATIVE = """<AdmRulService><행정규칙기본정보>
<행정규칙ID>201</행정규칙ID><행정규칙일련번호>2001</행정규칙일련번호>
<행정규칙명>합성 행정규칙</행정규칙명><발령일자>20250901</발령일자>
<시행일자>20260101</시행일자><발령번호>101</발령번호></행정규칙기본정보>
<조문내용>제1장 총칙</조문내용>
<조문내용>제1조(목적) 첫 번째 합성 본문.</조문내용>
<조문내용>① 첫 조문의 별도 항.</조문내용>
<조문내용>제2조(절차) 두 번째 합성 본문.</조문내용>
<조문내용>② 둘째 조문의 별도 항.</조문내용></AdmRulService>""".encode()

ORDINANCE_CATALOG = """<OrdinSearch><totalCnt>1</totalCnt><law>
<자치법규ID>301</자치법규ID><자치법규일련번호>3001</자치법규일련번호>
<자치법규명>합성 조례</자치법규명></law></OrdinSearch>""".encode()

FULL_ORDINANCE = """<LawService><자치법규기본정보>
<자치법규ID>301</자치법규ID><자치법규일련번호>3001</자치법규일련번호>
<자치법규명>합성 조례</자치법규명><공포일자>20250901</공포일자>
<시행일자>20260101</시행일자><공포번호>102</공포번호></자치법규기본정보>
<조문><조 조문번호="1"><조문번호>1</조문번호><조문여부>N</조문여부><조내용>제1장 총칙</조내용></조>
<조 조문번호="1"><조문번호>1</조문번호><조문여부>Y</조문여부><조제목>목적</조제목>
<조내용>제1조(목적) 합성 조례의 목적.</조내용></조>
<조 조문번호="2"><조문번호>2</조문번호><조문여부>Y</조문여부><조제목>절차</조제목>
<조내용>제2조(절차) 합성 조례의 절차.</조내용></조></조문></LawService>""".encode()


class LawSourceTests(unittest.TestCase):
    def client(self, handler, **kwargs) -> LawClient:
        client = LawClient(oc=OC, transport=httpx.MockTransport(handler), minimum_interval=0, **kwargs)
        self.addCleanup(client.close)
        return client

    @staticmethod
    def item(source: str = "law", source_id: str = "00123", version_id: str = "987") -> dict:
        return {"source": source, "source_id": source_id, "version_id": version_id,
                "title": "합성 검증용 법률", "metadata": {"version_identifier_type": "MST" if source == "law" else "ID"}}

    def assert_error(self, code: str, callback) -> LawSourceError:
        with self.assertRaises(LawSourceError) as caught:
            callback()
        self.assertEqual(caught.exception.code, code)
        self.assertNotIn(OC, str(caught.exception))
        return caught.exception

    def test_full_catalog_has_pagination_without_search_query_and_safe_provenance(self) -> None:
        requests = []
        def handler(request):
            requests.append(request)
            return httpx.Response(200, content=law_catalog(total=3))
        result = self.client(handler).catalog("statutes", page=2, page_size=1)
        self.assertEqual((result["source"], result["total"], result["total_pages"], result["page"]), ("law", 3, 3, 2))
        request = requests[0]
        self.assertEqual(request.url.path, "/DRF/lawSearch.do")
        self.assertEqual(dict(request.url.params), {"OC": OC, "target": "law", "type": "XML", "page": "2", "display": "1"})
        self.assertNotIn("query", request.url.params)
        item = result["items"][0]
        self.assertEqual((item["source_id"], item["version_id"]), ("00123", "987"))
        self.assertEqual(item["publication_date"], "2025-09-01")
        self.assertEqual(item["effective_date"], "2026-01-01")
        self.assertIn("MST=987", item["source_url"])
        self.assertNotIn(OC, json.dumps(result))
        self.assertFalse(item["metadata"]["provider_contract_verified"])

    def test_catalog_redacts_echoed_oc_in_metadata_links(self) -> None:
        data = law_catalog(extra=f"<법령상세링크>https://www.law.go.kr/DRF/lawService.do?OC={OC}&amp;MST=987</법령상세링크>")
        result = self.client(lambda _: httpx.Response(200, content=data)).catalog("law")
        self.assertNotIn(OC, json.dumps(result))
        self.assertNotIn("OC=", result["items"][0]["metadata"]["fields"]["법령상세링크"])

    def test_other_source_aliases_and_ordinance_law_item_shape(self) -> None:
        for source, root, node, id_tag, title_tag, canonical in [
            ("admrul", "AdmRulSearch", "admrul", "행정규칙일련번호", "행정규칙명", "administrative"),
            ("ordin", "OrdinSearch", "law", "자치법규일련번호", "자치법규명", "ordinance"),
        ]:
            with self.subTest(source=source):
                raw = f"<{root}><totalCnt>1</totalCnt><{node}><{id_tag}>12</{id_tag}><{title_tag}>합성 규정</{title_tag}></{node}></{root}>".encode()
                result = self.client(lambda _, raw=raw: httpx.Response(200, content=raw)).catalog(source)
                item = result["items"][0]
                self.assertEqual(item["source"], canonical)
                key = "MST" if canonical == "ordinance" else "ID"
                self.assertIn(f"{key}=12", item["source_url"])
                self.assertIsNone(item["publication_date"])
                self.assertIsNone(item["effective_date"])
                self.assertIn("missing_effective_date", item["metadata"]["parse_warnings"])

    def test_empty_catalog_only_succeeds_with_declared_zero_count(self) -> None:
        result = self.client(lambda _: httpx.Response(200, content=b"<LawSearch><totalCnt>0</totalCnt></LawSearch>")).catalog("law")
        self.assertEqual(result["items"], [])
        self.assertEqual(result["total_pages"], 0)
        self.assertTrue(result["supported"])

    def test_unknown_count_incomplete_page_missing_ids_and_schema_fail(self) -> None:
        examples = [
            (b"<LawSearch/>", "unknown_total"),
            (b"<LawSearch><totalCnt>invalid</totalCnt></LawSearch>", "unknown_total"),
            (b"<LawSearch><totalCnt>1</totalCnt></LawSearch>", "incomplete_page"),
            ("<LawSearch><totalCnt>1</totalCnt><law><법령명한글>합성</법령명한글></law></LawSearch>".encode(), "missing_identity"),
            (b"<AdmRulSearch><totalCnt>0</totalCnt></AdmRulSearch>", "unexpected_schema"),
        ]
        for raw, code in examples:
            with self.subTest(code=code):
                client = self.client(lambda _, raw=raw: httpx.Response(200, content=raw))
                self.assert_error(code, lambda: client.catalog("law"))

    def test_duplicate_versions_fail_even_when_total_matches(self) -> None:
        data = law_catalog().decode()
        node = data[data.index("<law>"):data.index("</law>") + 6]
        raw = f"<LawSearch><totalCnt>2</totalCnt>{node}{node}</LawSearch>".encode()
        client = self.client(lambda _: httpx.Response(200, content=raw))
        self.assert_error("duplicate_identity", lambda: client.catalog("law"))

    def test_same_stable_id_with_distinct_versions_is_retained(self) -> None:
        nodes = []
        for sequence in ("987", "988"):
            data = law_catalog(version_id=sequence).decode()
            nodes.append(data[data.index("<law>"):data.index("</law>") + 6])
        raw = f"<LawSearch><totalCnt>2</totalCnt>{''.join(nodes)}</LawSearch>".encode()
        result = self.client(lambda _: httpx.Response(200, content=raw)).catalog("law")
        self.assertEqual([item["version_id"] for item in result["items"]], ["987", "988"])

    def test_invalid_dates_are_absent_not_guessed(self) -> None:
        raw = law_catalog().replace(b"20250901", b"20250230").replace(b"2026-01-01", b"2026")
        item = self.client(lambda _: httpx.Response(200, content=raw)).catalog("law")["items"][0]
        self.assertIsNone(item["publication_date"])
        self.assertIsNone(item["effective_date"])
        self.assertEqual(item["metadata"]["parse_warnings"], ["invalid_publication_date", "invalid_effective_date"])

    def test_json_response_retains_the_same_catalog_contract(self) -> None:
        data = {"LawSearch": {"totalCnt": 1, "law": {"법령ID": "00123", "법령일련번호": "987", "법령명한글": "합성 법률"}}}
        result = self.client(lambda _: httpx.Response(200, json=data)).catalog("law")
        self.assertEqual(result["items"][0]["version_id"], "987")

    def test_full_document_preserves_exact_raw_and_structured_units(self) -> None:
        requests = []
        def handler(request):
            requests.append(request)
            return httpx.Response(200, content=FULL_LAW)
        document = self.client(handler).fetch_full(self.item())
        self.assertEqual(document["raw"], FULL_LAW)
        self.assertEqual(document["raw_format"], "xml")
        self.assertEqual(requests[0].url.params["MST"], "987")
        provision = document["provisions"][0]
        self.assertEqual(provision["article_no"], "제7조의2")
        paragraph = provision["paragraphs"][0]
        self.assertEqual((paragraph["paragraph_no"], paragraph["original_no"]), ("1", "①"))
        self.assertEqual(paragraph["items"][0]["item_no"], "1")
        self.assertIn("가. 원본 기록", paragraph["items"][0]["text"])
        self.assertIn("① 확인하여야 한다.", provision["text"])
        direct = document["provisions"][1]["paragraphs"][0]
        self.assertIsNone(direct["paragraph_no"])
        self.assertEqual(direct["items"][0]["item_no"], "2")
        self.assertNotIn(OC, document["source_url"])
        self.assertTrue(document["metadata"]["response_identity_verified"])
        self.assertTrue(document["metadata"]["response_version_verified"])
        self.assertTrue(document["metadata"]["unit_coverage"]["paragraphs"])
        self.assertFalse(document["metadata"]["unit_coverage"]["subitems"])

    def test_supplementary_and_annex_records_are_retained_with_download_limit(self) -> None:
        document = self.client(lambda _: httpx.Response(200, content=FULL_LAW)).fetch_full(self.item())
        metadata = document["metadata"]
        self.assertEqual(len(metadata["supplementary_provisions"]), 1)
        self.assertIn("2026년", metadata["supplementary_provisions"][0]["text"])
        self.assertEqual(metadata["attachment_count"], 1)
        self.assertEqual(metadata["attachments"][0]["title"], "신청서")
        self.assertEqual(len(metadata["attachments"][0]["urls"]), 1)
        self.assertFalse(metadata["attachments"][0]["downloaded"])
        self.assertFalse(metadata["full_legal_coverage_verified"])
        self.assertIn("attachment_files_not_downloaded", metadata["parse_warnings"])

    def test_numbered_chapter_heading_cannot_replace_or_duplicate_a_real_article(self) -> None:
        units = """<조문단위><조문번호>1</조문번호><조문여부>전문</조문여부>
        <조문내용>제1장 총칙</조문내용></조문단위>
        <조문단위><조문번호>1</조문번호><조문여부>조문</조문여부>
        <조문제목>목적</조문제목><조문내용>제1조(목적) 합성 검증의 목적이다.</조문내용></조문단위>
        <조문단위><조문번호>2</조문번호><조문여부>조문</조문여부>
        <조문내용>제2조 삭제</조문내용></조문단위>"""
        prefix, tail = FULL_LAW.decode().split("<조문>", 1)
        _, suffix = tail.split("</조문>", 1)
        raw = (prefix + "<조문>" + units + "</조문>" + suffix).encode()
        document = self.client(lambda _: httpx.Response(200, content=raw)).fetch_full(self.item())
        self.assertEqual([p["article_no"] for p in document["provisions"]], ["제1조", "제2조"])
        self.assertEqual(document["provisions"][0]["title"], "목적")
        self.assertIn("합성 검증의 목적", document["provisions"][0]["text"])
        self.assertEqual(document["provisions"][1]["text"], "제2조 삭제")
        self.assertTrue(document["provisions"][1]["deleted"])
        self.assertFalse(document["provisions"][0]["deleted"])
        self.assertNotIn("제1장 총칙", document["text"])
        self.assertIn("제1장 총칙".encode(), document["raw"])
        self.assertNotIn("unparsed_article_number", document["metadata"]["parse_warnings"])

    def test_only_whole_article_deletion_markers_are_deleted(self) -> None:
        deleted = ("삭제", "(삭제)", "[삭제]", "제2조 삭제", "제2조의3 삭제 <2020. 12. 31.>",
                   "제2조(삭제)", "제2조(기존 제목) 삭제", "제2조 삭제 [2020-12-31]")
        active = ("삭제 절차를 마련한다.", "제2조(삭제절차) 자료를 삭제한다.", "제2조 삭제된 자료의 보관",
                  "제2조 삭제\n남은 의무를 이행한다.", "제2조(삭제) 새 문구가 존재한다.",
                  "제2조 삭제 <새 의무>", "제2조 삭제 <2020.12.31]")
        for text in deleted:
            with self.subTest(text=text):
                self.assertTrue(is_deleted_article(text))
        for text in active:
            with self.subTest(text=text):
                self.assertFalse(is_deleted_article(text))

    def test_direct_article_item_keeps_subitem_obligations_in_searchable_text(self) -> None:
        raw = FULL_LAW.decode().replace("<호내용>2) 절차</호내용></호>",
            "<호내용>2) 절차</호내용><목><목번호>가.</목번호><목내용>가. 원본 보관 의무</목내용></목>"
            "<목단위><목번호>나.</목번호><목내용>나. 파기 기록 의무</목내용></목단위></호>").encode()
        document = self.client(lambda _: httpx.Response(200, content=raw)).fetch_full(self.item())
        direct = document["provisions"][1]["paragraphs"][0]["items"][0]
        self.assertEqual(direct["item_no"], "2")
        for obligation in ("가. 원본 보관 의무", "나. 파기 기록 의무"):
            self.assertIn(obligation, direct["text"])
            self.assertIn(obligation, document["provisions"][1]["text"])
            self.assertIn(obligation, document["text"])
        self.assertEqual(document["raw"], raw)

    def test_missing_header_dates_cannot_be_inferred_from_articles_or_supplementary(self) -> None:
        raw = FULL_LAW.decode().replace("<공포일자>20250901</공포일자>", "").replace(
            "<시행일자>20260101</시행일자>", "").replace("<공포번호>12345</공포번호>", "").replace(
            "<부칙단위>", "<부칙단위><공포일자>19990101</공포일자><공포번호>999</공포번호>").replace(
            "<조문번호>8</조문번호>", "<조문번호>8</조문번호><시행일자>19990201</시행일자>").encode()
        document = self.client(lambda _: httpx.Response(200, content=raw)).fetch_full(self.item())
        self.assertIsNone(document["publication_date"])
        self.assertIsNone(document["effective_date"])
        self.assertIsNone(document["publication_no"])
        self.assertIn("missing_publication_date", document["metadata"]["parse_warnings"])
        self.assertIn("missing_effective_date", document["metadata"]["parse_warnings"])
        self.assertEqual(document["raw"], raw)

    def test_header_identity_and_title_take_precedence_over_related_law_aliases(self) -> None:
        related = """<관련법령><법령ID>OTHER</법령ID><법령일련번호>OTHER-VERSION</법령일련번호>
        <법령명한글>합성 인용 법령 이름</법령명한글><공포일자>19990101</공포일자></관련법령>"""
        raw = FULL_LAW.decode().replace("</기본정보>", "</기본정보>" + related).encode()
        document = self.client(lambda _: httpx.Response(200, content=raw)).fetch_full(self.item())
        self.assertEqual(document["title"], "합성 검증용 법률")
        self.assertEqual(document["source_id"], "00123")
        self.assertEqual(document["metadata"]["response_version_id"], "987")
        self.assertEqual(document["publication_date"], "2025-09-01")

    def test_root_direct_headers_remain_supported_without_basic_information_wrapper(self) -> None:
        raw = FULL_LAW.replace("<기본정보>".encode(), b"").replace("</기본정보>".encode(), b"")
        document = self.client(lambda _: httpx.Response(200, content=raw)).fetch_full(self.item())
        self.assertEqual(document["title"], "합성 검증용 법률")
        self.assertEqual(document["publication_date"], "2025-09-01")
        self.assertEqual(document["effective_date"], "2026-01-01")
        self.assertTrue(document["metadata"]["response_version_verified"])

    def test_compound_law_key_is_not_confused_with_mst(self) -> None:
        raw = FULL_LAW.decode().replace("<법령>", '<법령 법령키="001232025090112345">').replace("<법령일련번호>987</법령일련번호>", "").encode()
        document = self.client(lambda _: httpx.Response(200, content=raw)).fetch_full(self.item())
        self.assertFalse(document["metadata"]["response_version_verified"])
        self.assertIn("missing_document_version", document["metadata"]["parse_warnings"])

    def test_law_sequence_without_stable_id_still_uses_mst(self) -> None:
        requests = []
        catalog = law_catalog().replace("<법령ID>00123</법령ID>".encode(), b"")
        full = FULL_LAW.replace("<법령ID>00123</법령ID>".encode(), b"")
        def handler(request):
            requests.append(request)
            return httpx.Response(200, content=catalog if request.url.path.endswith("lawSearch.do") else full)
        client = self.client(handler)
        item = client.catalog("law")["items"][0]
        self.assertEqual(item["source_id"], "987")
        client.fetch_full(item)
        self.assertEqual(requests[-1].url.params["MST"], "987")

    def test_law_with_only_stable_id_uses_id_not_mst(self) -> None:
        requests = []
        catalog = law_catalog().replace("<법령일련번호>987</법령일련번호>".encode(), b"")
        def handler(request):
            requests.append(request)
            return httpx.Response(200, content=catalog if request.url.path.endswith("lawSearch.do") else FULL_LAW)
        client = self.client(handler)
        item = client.catalog("law")["items"][0]
        self.assertEqual(item["metadata"]["version_identifier_type"], "ID")
        self.assertFalse(item["metadata"]["version_identifier_available"])
        document = client.fetch_full(item)
        self.assertEqual(requests[-1].url.params["ID"], "00123")
        self.assertNotIn("MST", requests[-1].url.params)
        self.assertEqual(document["version_id"], "00123")
        self.assertEqual(document["metadata"]["response_version_id"], "987")
        self.assertFalse(document["metadata"]["response_version_verified"])
        self.assertIn("requested_version_unverified", document["metadata"]["parse_warnings"])

    def test_zero_padded_article_and_extended_circle_numbers(self) -> None:
        raw = FULL_LAW.decode().replace("<조문번호>7</조문번호>", "<조문번호>0007</조문번호>").replace("<항번호>①</항번호>", "<항번호>㉑</항번호>").replace("<호번호>1.</호번호>", "<호번호>(1)</호번호>").encode()
        provision = self.client(lambda _: httpx.Response(200, content=raw)).fetch_full(self.item())["provisions"][0]
        self.assertEqual(provision["article_no"], "제7조의2")
        self.assertEqual(provision["metadata"]["original_article_no"], "0007")
        self.assertEqual(provision["metadata"]["branch_no"], "2")
        self.assertEqual(provision["paragraphs"][0]["paragraph_no"], "21")
        self.assertEqual(provision["paragraphs"][0]["items"][0]["item_no"], "1")

    def test_full_identity_and_version_mismatches_cannot_be_stored(self) -> None:
        for raw, code in [(FULL_LAW.replace(b"00123", b"00124"), "identity_mismatch"),
                          (FULL_LAW.replace(b">987<", b">988<"), "version_mismatch")]:
            with self.subTest(code=code):
                client = self.client(lambda _, raw=raw: httpx.Response(200, content=raw))
                self.assert_error(code, lambda: client.fetch_full(self.item()))

    def test_full_body_with_no_identity_is_unverifiable(self) -> None:
        raw = FULL_LAW.replace("<법령ID>00123</법령ID>".encode(), b"").replace("<법령일련번호>987</법령일련번호>".encode(), b"")
        client = self.client(lambda _: httpx.Response(200, content=raw))
        self.assert_error("identity_unverifiable", lambda: client.fetch_full(self.item()))

    def test_response_with_echoed_credential_is_blocked_before_raw_persistence(self) -> None:
        raw = FULL_LAW + f"<!-- https://www.law.go.kr/service?OC={OC} -->".encode()
        client = self.client(lambda _: httpx.Response(200, content=raw))
        self.assert_error("credential_in_response", lambda: client.fetch_full(self.item()))

    def test_unstructured_administrative_text_has_article_and_coverage_warning(self) -> None:
        raw = """<행정규칙><기본정보><행정규칙일련번호>12</행정규칙일련번호><행정규칙명>합성 지침</행정규칙명></기본정보>
        <조문내용><![CDATA[제1조(목적) 합성 내용.
제2조의3(절차) ① 확인한다.]]></조문내용></행정규칙>""".encode()
        document = self.client(lambda _: httpx.Response(200, content=raw)).fetch_full(self.item("administrative", "12", "12"))
        self.assertEqual([p["article_no"] for p in document["provisions"]], ["제1조", "제2조의3"])
        self.assertFalse(document["metadata"]["unit_coverage"]["paragraphs"])
        self.assertIn("unstructured_paragraphs", document["metadata"]["parse_warnings"])
        self.assertIsNone(document["effective_date"])

    def test_administrative_header_takes_precedence_over_other_metadata(self) -> None:
        other = """<기본정보><행정규칙ID>OTHER</행정규칙ID><행정규칙일련번호>OTHER-VERSION</행정규칙일련번호>
        <행정규칙명>다른 합성 규정</행정규칙명><발령일자>19990101</발령일자></기본정보>
        <행정규칙ID>ROOT-OTHER</행정규칙ID><관련규정><행정규칙ID>RELATED</행정규칙ID>
        <행정규칙일련번호>RELATED-VERSION</행정규칙일련번호></관련규정>"""
        raw = FULL_ADMINISTRATIVE.replace(b"<AdmRulService>", ("<AdmRulService>" + other).encode())
        document = self.client(lambda _: httpx.Response(200, content=raw)).fetch_full(self.item("administrative", "201", "2001"))
        self.assertEqual(document["title"], "합성 행정규칙")
        self.assertEqual(document["publication_date"], "2025-09-01")
        self.assertEqual(document["effective_date"], "2026-01-01")
        self.assertEqual(document["publication_no"], "101")
        self.assertTrue(document["metadata"]["response_identity_verified"])
        self.assertTrue(document["metadata"]["response_version_verified"])

    def test_administrative_missing_header_identity_is_not_borrowed_from_related_rule(self) -> None:
        raw = FULL_ADMINISTRATIVE.decode().replace("<행정규칙ID>201</행정규칙ID>", "").replace(
            "<행정규칙일련번호>2001</행정규칙일련번호>", "").replace(
            "</행정규칙기본정보>", "</행정규칙기본정보><관련규정><행정규칙ID>201</행정규칙ID>"
            "<행정규칙일련번호>2001</행정규칙일련번호></관련규정>").encode()
        client = self.client(lambda _: httpx.Response(200, content=raw))
        self.assert_error("identity_unverifiable", lambda: client.fetch_full(self.item("administrative", "201", "2001")))

    def test_administrative_missing_header_dates_are_not_borrowed_from_supplementary(self) -> None:
        raw = FULL_ADMINISTRATIVE.decode().replace("<발령일자>20250901</발령일자>", "").replace(
            "<시행일자>20260101</시행일자>", "").replace("<발령번호>101</발령번호>", "").replace(
            "</AdmRulService>", "<부칙><발령일자>19990101</발령일자><시행일자>19990201</시행일자>"
            "<발령번호>999</발령번호></부칙></AdmRulService>").encode()
        document = self.client(lambda _: httpx.Response(200, content=raw)).fetch_full(self.item("administrative", "201", "2001"))
        self.assertIsNone(document["publication_date"])
        self.assertIsNone(document["effective_date"])
        self.assertIsNone(document["publication_no"])

    def test_administrative_mismatching_identity_or_version_is_rejected(self) -> None:
        for field, original, replacement, code in [
            ("행정규칙ID", "201", "202", "identity_mismatch"),
            ("행정규칙일련번호", "2001", "2002", "version_mismatch"),
        ]:
            with self.subTest(code=code):
                raw = FULL_ADMINISTRATIVE.decode().replace(f"<{field}>{original}</{field}>",
                    f"<{field}>{replacement}</{field}>").replace("<AdmRulService>",
                    f"<AdmRulService><{field}>{original}</{field}>").encode()
                client = self.client(lambda _, raw=raw: httpx.Response(200, content=raw))
                self.assert_error(code, lambda: client.fetch_full(self.item("administrative", "201", "2001")))

    def test_repeated_administrative_content_preserves_preamble_and_every_fragment(self) -> None:
        document = self.client(lambda _: httpx.Response(200, content=FULL_ADMINISTRATIVE)).fetch_full(self.item("administrative", "201", "2001"))
        fragments = ["제1장 총칙", "제1조(목적) 첫 번째 합성 본문.", "① 첫 조문의 별도 항.",
                     "제2조(절차) 두 번째 합성 본문.", "② 둘째 조문의 별도 항."]
        self.assertEqual(document["text"], "\n".join(fragments))
        self.assertEqual([p["article_no"] for p in document["provisions"]], ["제1조", "제2조"])
        self.assertEqual(document["provisions"][0]["text"], "\n".join(fragments[1:3]))
        self.assertEqual(document["provisions"][1]["text"], "\n".join(fragments[3:]))
        self.assertEqual(document["raw"], FULL_ADMINISTRATIVE)
        self.assertIn("unstructured_paragraphs", document["metadata"]["parse_warnings"])

    def test_repeated_content_without_article_numbers_is_preserved(self) -> None:
        raw = FULL_ADMINISTRATIVE.decode().replace("제1조(목적)", "목적:").replace("제2조(절차)", "절차:").encode()
        document = self.client(lambda _: httpx.Response(200, content=raw)).fetch_full(self.item("administrative", "201", "2001"))
        self.assertEqual(document["provisions"], [])
        self.assertIn("첫 번째 합성 본문.", document["text"])
        self.assertIn("둘째 조문의 별도 항.", document["text"])
        self.assertIn("unparsed_provisions", document["metadata"]["parse_warnings"])

    def test_structured_articles_are_not_duplicated_by_direct_summary_fields(self) -> None:
        summary = "<조문내용>제7조의2(검증) 검증의 범위는 다음과 같다.</조문내용>"
        raw = FULL_LAW.replace("</법령>".encode(), (summary + "</법령>").encode())
        document = self.client(lambda _: httpx.Response(200, content=raw)).fetch_full(self.item())
        self.assertEqual(document["text"].count("제7조의2(검증) 검증의 범위는 다음과 같다."), 1)
        self.assertEqual(len(document["provisions"]), 2)
        self.assertNotIn("unstructured_paragraphs", document["metadata"]["parse_warnings"])

    def test_ordinance_version_uses_mst_and_parses_its_own_header_and_articles(self) -> None:
        requests = []
        def handler(request):
            requests.append(request)
            return httpx.Response(200, content=ORDINANCE_CATALOG if request.url.path.endswith("lawSearch.do") else FULL_ORDINANCE)
        client = self.client(handler)
        item = client.catalog("ordinance", page_size=1)["items"][0]
        self.assertEqual(item["metadata"]["version_identifier_type"], "MST")
        document = client.fetch_full(item)
        self.assertEqual(dict(requests[-1].url.params), {"OC": OC, "target": "ordin", "type": "XML", "MST": "3001"})
        self.assertEqual(document["title"], "합성 조례")
        self.assertEqual(document["publication_date"], "2025-09-01")
        self.assertEqual(document["effective_date"], "2026-01-01")
        self.assertEqual(document["publication_no"], "102")
        self.assertEqual([p["article_no"] for p in document["provisions"]], ["제1조", "제2조"])
        self.assertEqual(document["provisions"][0]["title"], "목적")
        self.assertNotIn("제1장 총칙", document["text"])
        self.assertTrue(document["metadata"]["response_identity_verified"])
        self.assertTrue(document["metadata"]["response_version_verified"])

    def test_ordinance_with_only_stable_id_uses_id_without_claiming_version_verified(self) -> None:
        catalog = ORDINANCE_CATALOG.replace("<자치법규일련번호>3001</자치법규일련번호>".encode(), b"")
        requests = []
        def handler(request):
            requests.append(request)
            return httpx.Response(200, content=catalog if request.url.path.endswith("lawSearch.do") else FULL_ORDINANCE)
        client = self.client(handler)
        item = client.catalog("ordinance", page_size=1)["items"][0]
        document = client.fetch_full(item)
        self.assertEqual(requests[-1].url.params["ID"], "301")
        self.assertNotIn("MST", requests[-1].url.params)
        self.assertFalse(document["metadata"]["response_version_verified"])
        self.assertIn("requested_version_unverified", document["metadata"]["parse_warnings"])

    def test_ordinance_mismatching_header_identity_or_version_is_rejected(self) -> None:
        for original, replacement, code in [(b">301<", b">302<", "identity_mismatch"),
                                            (b">3001<", b">3002<", "version_mismatch")]:
            with self.subTest(code=code):
                raw = FULL_ORDINANCE.replace(original, replacement)
                client = self.client(lambda _, raw=raw: httpx.Response(200, content=raw))
                self.assert_error(code, lambda: client.fetch_full(self.item("ordinance", "301", "3001")))

    def test_ordinance_empty_or_wrong_source_body_is_rejected(self) -> None:
        for raw in [b"<Law/>", FULL_LAW, b"<LawService><basicInfo/></LawService>"]:
            with self.subTest(raw=raw[:30]):
                client = self.client(lambda _, raw=raw: httpx.Response(200, content=raw))
                self.assert_error("unexpected_schema", lambda: client.fetch_full(self.item("ordinance", "301", "3001")))

    def test_unstructured_deleted_article_is_marked_without_deleting_active_mentions(self) -> None:
        raw = """<행정규칙><기본정보><행정규칙일련번호>12</행정규칙일련번호><행정규칙명>합성 지침</행정규칙명></기본정보>
        <조문내용><![CDATA[제1조(삭제절차) 정보를 삭제하는 절차를 정한다.
제2조 삭제 <2020. 12. 31.>]]></조문내용></행정규칙>""".encode()
        document = self.client(lambda _: httpx.Response(200, content=raw)).fetch_full(self.item("administrative", "12", "12"))
        self.assertFalse(document["provisions"][0]["deleted"])
        self.assertTrue(document["provisions"][1]["deleted"])
        self.assertEqual(document["raw"], raw)

    def test_xml_entities_login_and_api_errors_fail_without_leaking_bodies(self) -> None:
        fixtures = [(b'<!DOCTYPE LawSearch [<!ENTITY x "unsafe">]><LawSearch/>', "unsafe_xml"),
                    ('<!DOCTYPE LawSearch [<!ENTITY x "unsafe">]><LawSearch/>'.encode("utf-16"), "unsafe_xml"),
                    (b"<html><body>login</body></html>", "api_error"),
                    (b"<Error><message>unsupported target</message></Error>", "unsupported_source"),
                    (b"broken XML", "invalid_response")]
        for raw, code in fixtures:
            with self.subTest(code=code):
                client = self.client(lambda _, raw=raw: httpx.Response(200, content=raw))
                self.assert_error(code, lambda: client.catalog("law"))

    def test_403_is_not_retried_or_mislabeled_missing_credentials(self) -> None:
        attempts = []
        def handler(request):
            attempts.append(request)
            return httpx.Response(403, text=f"proxy denied https://law.go.kr?OC={OC}")
        error = self.assert_error("access_denied", lambda: self.client(handler).catalog("law"))
        self.assertEqual(error.status_code, 403)
        self.assertFalse(error.retriable)
        self.assertEqual(len(attempts), 1)

    def test_transient_failure_has_bounded_retries_and_retry_after(self) -> None:
        attempts = []
        def handler(request):
            attempts.append(request)
            return httpx.Response(429, headers={"Retry-After": "9999"}) if len(attempts) == 1 else httpx.Response(200, content=law_catalog())
        with patch("rulecraft.law_sources.time.sleep") as sleep:
            result = self.client(handler, retries=1).catalog("law")
        self.assertEqual(result["total"], 1)
        self.assertEqual(len(attempts), 2)
        sleep.assert_called_once_with(5.0)

    def test_proxy_connect_403_is_not_retried_and_never_exposes_credentials(self) -> None:
        attempts = []
        def handler(request):
            attempts.append(request)
            raise httpx.ProxyError(f"403 Forbidden CONNECT https://www.law.go.kr/DRF?OC={OC}", request=request)
        with patch("rulecraft.law_sources.time.sleep") as sleep:
            error = self.assert_error("proxy_access_denied", lambda: self.client(handler, retries=3).catalog("law"))
        self.assertEqual(error.status_code, 403)
        self.assertFalse(error.retriable)
        self.assertEqual(error.source, "law")
        self.assertEqual(len(attempts), 1)
        sleep.assert_not_called()
        self.assertNotIn("https://", str(error))
        self.assertNotIn(OC, json.dumps(error.as_dict()))

    def test_other_proxy_failures_keep_bounded_network_retries(self) -> None:
        attempts = []
        def handler(request):
            attempts.append(request)
            raise httpx.ProxyError(f"502 proxy unavailable https://www.law.go.kr?OC={OC}", request=request)
        with patch("rulecraft.law_sources.time.sleep") as sleep:
            error = self.assert_error("network_error", lambda: self.client(handler, retries=1).catalog("law"))
        self.assertTrue(error.retriable)
        self.assertIsNone(error.status_code)
        self.assertEqual(len(attempts), 2)
        sleep.assert_called_once_with(.25)
        self.assertNotIn("https://", str(error))

    def test_network_errors_do_not_expose_httpx_exception_url(self) -> None:
        def handler(request):
            raise httpx.ConnectError(f"connection failed {request.url}", request=request)
        error = self.assert_error("network_error", lambda: self.client(handler, retries=0).catalog("law"))
        self.assertTrue(error.retriable)
        self.assertNotIn("https://", str(error))

    def test_streamed_response_size_is_bounded(self) -> None:
        client = self.client(lambda _: httpx.Response(200, content=law_catalog()))
        with patch("rulecraft.law_sources.MAX_RESPONSE_BYTES", 64):
            self.assert_error("response_too_large", lambda: client.catalog("law"))

    def test_environment_binding_is_used_without_outbound_when_missing(self) -> None:
        with patch.dict(os.environ, {"RULECRAFT_LAW_OC": ""}, clear=False):
            client = LawClient(transport=httpx.MockTransport(lambda _: self.fail("must not send")))
            self.addCleanup(client.close)
            self.assertFalse(client.configured)
            self.assert_error("missing_credentials", lambda: client.catalog("law"))

    def test_unsafe_base_configuration_and_pagination_fail_early(self) -> None:
        for base in ["http://www.law.go.kr/DRF", "https://user:pass@www.law.go.kr/DRF", "https://www.law.go.kr/DRF?OC=secret", "https://www.law.go.kr/DRF#fragment"]:
            with self.subTest(base=base):
                self.assert_error("invalid_configuration", lambda: LawClient(oc=OC, base_url=base))
        client = self.client(lambda _: self.fail("must not send"))
        for page, size in [(0, 100), (True, 1), (1, 101), (1, 0), (1, True)]:
            self.assert_error("invalid_pagination", lambda: client.catalog("law", page=page, page_size=size))
        self.assert_error("unsupported_source", lambda: client.catalog("unknown"))

    def test_tls_verification_and_environment_proxy_trust_are_preserved(self) -> None:
        with patch("rulecraft.law_sources.httpx.Client") as constructor:
            client = LawClient(oc=OC)
        self.assertTrue(constructor.call_args.kwargs["verify"])
        self.assertTrue(constructor.call_args.kwargs["trust_env"])
        self.assertFalse(constructor.call_args.kwargs["follow_redirects"])
        client.close()


if __name__ == "__main__":
    unittest.main()
